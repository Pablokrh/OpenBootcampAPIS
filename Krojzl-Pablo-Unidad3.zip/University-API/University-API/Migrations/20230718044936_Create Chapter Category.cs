﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace University_API.Migrations
{
    /// <inheritdoc />
    public partial class CreateChapterCategory : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
